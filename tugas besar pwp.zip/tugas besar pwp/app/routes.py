from flask import Blueprint, render_template, redirect, url_for, flash, request, session
from . import db
from .models import User
from .forms import RegistrationForm, LoginForm, EditUserForm
from werkzeug.security import generate_password_hash, check_password_hash
from sqlalchemy.exc import OperationalError

main_bp = Blueprint('main', __name__)

@main_bp.before_app_request  # Ganti sebelum request aplikasi, bukan sebelum request blueprint
def test_db_connection():
    try:
        # Coba untuk melakukan query ringan
        db.session.execute('SELECT 1')
        print("Koneksi ke database berhasil!")
    except OperationalError as e:
        print("Gagal terhubung ke database:", e)
        # Flash pesan kesalahan ke pengguna
        flash('Gagal terhubung ke database! Silakan periksa konfigurasi database.', 'danger')

@main_bp.route('/')
def home():
    return render_template('home.html')

@main_bp.route('/register', methods=['GET', 'POST'])
def register():
    forms = RegistrationForm()
    if forms.validate_on_submit():
        user = User(
            username=forms.username.data,
            email=forms.email.data
        )
        user.set_password(forms.password.data)
        try:
            db.session.add(user)
            db.session.commit()
            flash('Registration successful!', 'success')
            return redirect(url_for('main.login'))
        except Exception as e:
            db.session.rollback()
            if 'UNIQUE constraint failed' in str(e):
                flash('Username or email already exists. Please choose a different one.', 'danger')
            else:
                flash(f'An error occurred: {str(e)}', 'danger')
    return render_template('register.html', form=forms)

@main_bp.route('/login', methods=['GET', 'POST'])
def login():
    form = LoginForm()
    if form.validate_on_submit():
        user = User.query.filter_by(username=form.username.data).first()
        if user and user.check_password(form.password.data):
            session['user_id'] = user.id
            session['username'] = user.username
            return redirect(url_for('main.dashboard'))
        flash('Invalid username or password', 'danger')
    return render_template('login.html', form=form)

@main_bp.route('/dashboard')
def dashboard():
    if 'user_id' not in session:
        return redirect(url_for('main.login'))
    users = User.query.all()
    return render_template('dashboard.html', users=users)

@main_bp.route('/logout')
def logout():
    session.clear()
    return redirect(url_for('main.login'))
